function tip(msg)
{
	layer.open({
        type: 1
        ,offset: 'auto'
        ,id: 'layerDemo'
        ,content: '<div style="padding: 20px 100px;">'+ msg +'</div>'
        ,btn: '确认'
        ,btnAlign: 'c' //按钮居中
        ,shade: 0 //不显示遮罩
        ,yes: function(){
          layer.closeAll();
        }
      });
}