/**
 * Created by Jill on 16/11/19.
 * @author :  jill
 * @jill's blog : http://blog.csdn.net/jill6693484
 */


function kefu(element, imgSrc, nickname, datetime, doctextContent) {
	//判断传入的值，是医生还是患者
	//获取输入的值
	//var $textContent = $('.msg')[0].value;
	//获取传入的医生输入的内容
	var $doctextContent = doctextContent;
	//获取容器
	var $box_content = $('.contentmessage');
	var $box = $('.messageWindow');
	//医生
	if (element === "leftBubble") {
		$box.append(createquest(imgSrc, nickname,datetime,$doctextContent));
		
		$('#contentmessage').scrollTop($('#contentmessage')[0].scrollHeight);
	}
	//患者
	else if (element === "rightBubble") {
		$box.append(createrobot(imgSrc, nickname,datetime,$doctextContent));
		
		$('#contentmessage').scrollTop($('#contentmessage')[0].scrollHeight);
	} else {
		console.log("请传入必须的参数");
	}
};

function createquest(imgSrc, nickname, datetime, doctextContent) {
	var $imageHead = imgSrc;
	var $Nickname = nickname;
	var $Datetime = datetime;
	var $textContent = doctextContent;
	var block;
	if ($textContent == '' || $textContent == 'null') {
		alert('内容不能为空');
		return;
	}
	block = '<table class="msgItem msgUsr"><tbody><tr><td class="msgItem1">'
			+ '<img src="' + $imageHead + '"></td><td class="msgItem2">'
			+ '<span class="msgName">' + $Nickname + '</span>'
			+ '<span class="msgTime">' + $Datetime + '</span><br>'
			+ '<div class="bubble bubbleL bubbleU3">' + $textContent + '</div></td></tr></tbody></table>';
	return block;
}


function createuser(imgSrc, nickname, datetime, doctextContent) {
	var $imageHead = imgSrc;
	var $Nickname = nickname;
	var $Datetime = datetime;
	var $textContent = doctextContent;
	var block;
	if ($textContent == '' || $textContent == 'null') {
		alert('内容不能为空');
		return;
	}
	block = '<table class="msgItem msgUsr"><tbody><tr><td class="msgItem1">'
			+ '<img src="' + $imageHead + '"></td><td class="msgItem2">'
			+ '<span class="msgName">' + $Nickname + '</span>'
			+ '<span class="msgTime">' + $Datetime + '</span><br>'
			+ '<div class="bubble bubbleL bubbleU3"><a href="javascript:void(0)" style="color:black;" onclick="post(\'' + $textContent + '\')">' + $textContent + '</a></div></td></tr></tbody></table>';
	return block;
}

function createrobot(imgSrc, nickname, datetime, doctextContent) {
	var $imageHead = imgSrc;
	var $Nickname = nickname;
	var $Datetime = datetime;
	var $textContent = doctextContent;
	var block;
	if ($textContent == '' || $textContent == 'null') {
		alert('内容不能为空');
		return;
	}
	block = '<table class="msgItem msgSys"><tbody><tr><td class="msgItem2"><span class="msgName">'
			+ $Nickname + '</span>'
			+ '<span class="msgTime">' + $Datetime + '</span><br>'
			+ '<div align="center" class="bubble bubbleR bubbleS3">' + $textContent + '</div></td><td class="msgItem1">'
			+ '<img src="../images/robot_kefu.png"></td></tr></tbody></table>';
	return block;
};