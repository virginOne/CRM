$(document).ready(function() 
{
	var orderField = $("#orderField").val();
	var orderKey = $("#orderKey").val();
	if (""!=orderField && ""!=orderKey)
	{
		var thOrder = $("#th_" + orderField.replace(".","\\."));
		if (orderKey == "desc")
		{
			thOrder.attr("orderKey","asc");
		}
		else
		{
		
			thOrder.attr("orderKey","desc");
		}
	}
})

function sort(orderField)
{
	var thObj = $("#th_" + orderField.replace(".","\\."));
	var oderKey = thObj.attr("orderKey");
	$("#orderField").val(orderField);
	$("#orderKey").val(oderKey);
	tpage(1);
}