
function tpage(t) {
	$("#currentPage").val(t);
	$("#searchFrom").submit();
}
/*
function formatDate(now) {
	return new Date(now).toLocaleString().replace(/年|月/g, "-").replace(/日/g, " ");  
}*/
function gourl(url) {
	window.location.href=url;
}

function gourl2(url,level) {
	if (level >= 10)
	{
		alert("未授权创建一级11代理");
	}
	else
	{
		window.location.href=url;
	}
}

function formatThousand(num) {
    return (num.toFixed(2) + '').replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,');
}
 
function showunusedwarn() {
	alert("功能未开放");
}